<?php
// session_start();
// if(array_key_exists('auth__clear',$_SESSION)){
//     if($_SESSION['auth__clear'] == true){
//         header("Location:pages/order.php");
//         exit();
//     }
// }
