<?php
session_start();

error_reporting(-1);
ini_set('display_errors', 'On');
set_error_handler("var_dump");

function send_mail($msg)
{
//     $headers = array("From: from@example.com",
//     "Reply-To: replyto@example.com",
//     "X-Mailer: PHP/" . PHP_VERSION
// );
$headers = implode("\r\n", $headers);
    // return mail($_SESSION['order_fields']['user_email'], "Автосалон", $msg,$headers);
    return mail($_SESSION['order_fields']['user_email'], "Автосалон", $msg);
    // return mail("paramonpav@yandex.ru", "Автосалон", $msg,$headers);

}

if(isset($_SESSION['order_fields']) && isset($_SESSION['bill_fields'])){
    $filename="order.txt";
    // file_get_contents($filename)
    if(file_get_contents($filename)){echo 'Send';};
    echo '-'.$_SESSION['order_fields']['user_email'].'-';
    // header("Location:../index.php");
}
