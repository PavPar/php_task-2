<?php
$prices = array(
    'service_type-sale' => 100,
    'service_type-prokat' => 500,
    'service_type-lizing' => 2100,
    'service__extra-leather' => 50,
    'service__extra-heater' => 30,
    'service__extra-luke' => 100,
    "car_mark-peugeot" => 200,
    "car_mark-lada" => 100,
    "car_mark-nissan" => 300,
    "car_mark-сitroen" => 500,
    "car_mark-skoda" => 300,
    "car_mark-lexus" => 800,
    "car_mark-kia" => 50,
    "car_mark-honda" => 100,
    "car_mark-mazda" => 80,
    "car_extra-benzin" => 50,
    "car_extra-tires" => 100,
    "car_extra-jojo" => 100,
    "car_extra-saloon" => 50,
);
?>


